import { eventService } from "../services/event.service";

export Eventlist(){

    
}